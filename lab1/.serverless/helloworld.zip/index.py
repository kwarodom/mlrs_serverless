def handler(event,context):
    print('Log event',event)
    return 'Hello world'